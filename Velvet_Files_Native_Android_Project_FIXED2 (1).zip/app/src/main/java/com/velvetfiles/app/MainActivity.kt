package com.velvetfiles.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

private val Ink = Color(0xFF05040A)
private val Panel = Color(0xFF12101A)
private val Glass = Color(0xCC21172F)
private val Purple = Color(0xFFBD7BFF)
private val Muted = Color(0xFFB7ADC8)
private val Border = Color(0xFF49365F)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FileManagerApp() }
    }
}

data class Entry(val name: String, val uri: Uri, val directory: Boolean, val size: Long, val modified: Long, val mime: String?)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileManagerApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var rootUri by remember { mutableStateOf<Uri?>(null) }
    var currentFolder by remember { mutableStateOf<DocumentFile?>(null) }
    var folderStack by remember { mutableStateOf(listOf<Uri>()) }
    var entries by remember { mutableStateOf<List<Entry>>(emptyList()) }
    var pathTitle by remember { mutableStateOf("Internal storage") }
    var search by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf("Name · A–Z") }
    var sortMenu by remember { mutableStateOf(false) }
    var grid by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var compact by remember { mutableStateOf(false) }
    var accent by remember { mutableStateOf(Purple) }
    var selected by remember { mutableStateOf<Entry?>(null) }
    var actionMenu by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf("") }
    var textValue by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Choose a folder to start browsing") }

    fun refresh(folder: DocumentFile? = currentFolder) {
        scope.launch { entries = loadEntries(folder); status = "${entries.size} items" }
    }
    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) } catch (_: Exception) {}
            rootUri = uri
            currentFolder = DocumentFile.fromTreeUri(context, uri)
            folderStack = listOf(uri)
            pathTitle = currentFolder?.name ?: "Internal storage"
            search = ""
            refresh(currentFolder)
        }
    }
    val filtered = entries.filter { it.name.contains(search, ignoreCase = true) }
    val sorted = when (sort) {
        "Name · Z–A" -> filtered.sortedByDescending { it.name.lowercase() }
        "Newest first" -> filtered.sortedByDescending { it.modified }
        "Oldest first" -> filtered.sortedBy { it.modified }
        "Largest first" -> filtered.sortedByDescending { it.size }
        "Smallest first" -> filtered.sortedBy { it.size }
        "Folders first" -> filtered.sortedWith(compareBy<Entry> { !it.directory }.thenBy { it.name.lowercase() })
        "Files first" -> filtered.sortedWith(compareBy<Entry> { it.directory }.thenBy { it.name.lowercase() })
        else -> filtered.sortedWith(compareBy<Entry> { !it.directory }.thenBy { it.name.lowercase() })
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = accent, secondary = accent, background = Ink, surface = Panel, onSurface = Color.White, onBackground = Color.White)) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Color(0xFF0D0A13), contentColor = accent) {
                NavigationBarItem(selected = true, onClick = { if (rootUri == null) folderPicker.launch(null) else { currentFolder = DocumentFile.fromTreeUri(context, rootUri!!); pathTitle = currentFolder?.name ?: "Internal storage"; folderStack = listOf(rootUri!!); refresh(currentFolder) } }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                NavigationBarItem(selected = false, onClick = { search = ""; sort = "Newest first" }, icon = { Icon(Icons.Default.History, null) }, label = { Text("Recent") })
                NavigationBarItem(selected = false, onClick = { folderPicker.launch(rootUri) }, icon = { Icon(Icons.Default.FolderOpen, null) }, label = { Text("Browse") })
            }
        }, floatingActionButton = {
            FloatingActionButton(onClick = { dialog = "create"; textValue = "" }, containerColor = accent, contentColor = Ink) { Icon(Icons.Default.CreateNewFolder, "Create folder") }
        }) { padding ->
            Column(Modifier.fillMaxSize().background(Ink).padding(padding).padding(horizontal = 16.dp)) {
                Spacer(Modifier.height(16.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Box(Modifier.size(46.dp).clip(RoundedCornerShape(16.dp)).background(Glass), contentAlignment = Alignment.Center) { Icon(Icons.Default.FolderSpecial, null, tint = accent, modifier = Modifier.size(28.dp)) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("File Manager", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold, color = Color.White)
                        Text("AMOLED  ·  LIQUID GLASS", style = MaterialTheme.typography.labelSmall, color = accent)
                    }
                    IconButton(onClick = { settings = !settings }) { Icon(Icons.Default.Tune, "Appearance settings", tint = accent) }
                }
                Spacer(Modifier.height(14.dp))
                if (settings) Card(colors = CardDefaults.cardColors(containerColor = Glass), shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth().animateContentSize()) {
                    Column(Modifier.padding(14.dp)) {
                        Text("PERSONALIZE", color = accent, fontWeight = FontWeight.Bold)
                        Text("Accent colour", color = Muted, style = MaterialTheme.typography.bodySmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(vertical = 8.dp)) {
                            listOf(Purple, Color(0xFF63E5FF), Color(0xFFFF7BB7), Color(0xFFB5F36A), Color(0xFFFFC76B)).forEach { c ->
                                Box(Modifier.size(30.dp).clip(RoundedCornerShape(50)).background(c).clickable { accent = c }, contentAlignment = Alignment.Center) { if (accent == c) Icon(Icons.Default.Check, null, tint = Ink) }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) { Text("Compact list rows", color = Color.White, modifier = Modifier.weight(1f)); Switch(compact, { compact = it }) }
                    }
                }
                Card(colors = CardDefaults.cardColors(containerColor = Glass), shape = RoundedCornerShape(24.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(15.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(enabled = folderStack.size > 1, onClick = {
                                if (folderStack.size > 1) {
                                    val nextStack = folderStack.dropLast(1); folderStack = nextStack
                                    val doc = findDocument(context, rootUri, nextStack.last())
                                    currentFolder = doc; pathTitle = doc?.name ?: "Internal storage"; refresh(doc)
                                }
                            }) { Icon(Icons.Default.ArrowBack, "Back", tint = if (folderStack.size > 1) accent else Muted) }
                            Column(Modifier.weight(1f)) {
                                Text(pathTitle, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${entries.size} items  ·  $status", color = Muted, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            IconButton(onClick = { refresh() }) { Icon(Icons.Default.Refresh, "Refresh", tint = accent) }
                        }
                        OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Search files and folders") }, leadingIcon = { Icon(Icons.Default.Search, null, tint = accent) }, shape = RoundedCornerShape(16.dp), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = accent, unfocusedBorderColor = Border, focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedContainerColor = Ink, unfocusedContainerColor = Ink))
                        Spacer(Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box {
                                TextButton(onClick = { sortMenu = true }) { Icon(Icons.Default.Sort, null, tint = accent); Spacer(Modifier.width(6.dp)); Text(sort, color = Color.White) }
                                DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                                    listOf("Folders first", "Files first", "Name · A–Z", "Name · Z–A", "Newest first", "Oldest first", "Largest first", "Smallest first").forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { sort = option; sortMenu = false }) }
                                }
                            }
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = { grid = false }) { Icon(Icons.Default.ViewList, "List view", tint = if (!grid) accent else Muted) }
                            IconButton(onClick = { grid = true }) { Icon(Icons.Default.GridView, "Grid view", tint = if (grid) accent else Muted) }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                if (rootUri == null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.FolderOpen, null, tint = accent, modifier = Modifier.size(66.dp))
                            Spacer(Modifier.height(12.dp)); Text("Your files, beautifully organized", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("Grant access to a folder on your device to begin.", color = Muted)
                            Spacer(Modifier.height(12.dp)); Button(onClick = { folderPicker.launch(null) }, colors = ButtonDefaults.buttonColors(containerColor = accent, contentColor = Ink)) { Text("Choose storage folder") }
                        }
                    }
                } else if (sorted.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.FolderOff, null, tint = Muted, modifier = Modifier.size(42.dp)); Text(if (search.isBlank()) "This folder is empty" else "No matching items", color = Muted) } }
                } else if (grid) {
                    LazyVerticalGrid(columns = GridCells.Adaptive(145.dp), contentPadding = PaddingValues(bottom = 90.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        gridItems(sorted, key = { it.uri.toString() }) { e -> FileTile(e, accent) { selected = e; actionMenu = true } }
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
                        items(sorted, key = { it.uri.toString() }) { e -> FileRow(e, accent, compact, onClick = {
                            if (e.directory) {
                                val doc = findDocument(context, rootUri, e.uri)
                                if (doc != null) { currentFolder = doc; folderStack = folderStack + e.uri; pathTitle = e.name; search = ""; refresh(doc) } else status = "Unable to open this folder"
                            } else openFile(context, e)
                        }, onLongClick = { selected = e; actionMenu = true }) }
                    }
                }
            }
        }

        if (actionMenu && selected != null) AlertDialog(onDismissRequest = { actionMenu = false }, containerColor = Panel, title = { Text(selected!!.name, color = Color.White) }, text = { Text("Choose an action for this ${if (selected!!.directory) "folder" else "file"}.", color = Muted) }, confirmButton = {
            TextButton(onClick = { val e = selected!!; actionMenu = false; selected = null; if (e.directory) { val doc = findDocument(context, rootUri, e.uri); if (doc != null) { currentFolder = doc; folderStack = folderStack + e.uri; pathTitle = e.name; refresh(doc) } } else openFile(context, e) }) { Text("Open", color = accent) }
        }, dismissButton = {
            Row {
                TextButton(onClick = { textValue = selected!!.name; dialog = "rename"; actionMenu = false }) { Text("Rename", color = accent) }
                TextButton(onClick = { dialog = "delete"; actionMenu = false }) { Text("Delete", color = Color(0xFFFF8A9A)) }
                TextButton(onClick = { val e = selected!!; try { val i = Intent(Intent.ACTION_SEND).apply { type = e.mime ?: "*/*"; putExtra(Intent.EXTRA_STREAM, e.uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }; context.startActivity(Intent.createChooser(i, "Share file")) } catch (_: Exception) { status = "Could not share item" }; actionMenu = false }) { Text("Share", color = accent) }
            }
        })

        if (dialog == "create" || dialog == "rename" || dialog == "delete") {
            AlertDialog(onDismissRequest = { dialog = "" }, containerColor = Panel,
                title = { Text(when (dialog) { "create" -> "New folder"; "rename" -> "Rename item"; else -> "Delete item?" }, color = Color.White) },
                text = { if (dialog == "delete") Text("This action cannot be undone.", color = Muted) else OutlinedTextField(value = textValue, onValueChange = { textValue = it }, singleLine = true, label = { Text("Name") }, colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = accent, focusedTextColor = Color.White, unfocusedTextColor = Color.White)) },
                confirmButton = { TextButton(onClick = {
                    val folder = currentFolder
                    when (dialog) {
                        "create" -> { if (!textValue.isBlank() && folder != null) { val ok = folder.createDirectory(textValue.trim()); status = if (ok != null) "Folder created" else "Could not create folder"; refresh(folder) } }
                        "rename" -> { val e = selected; val doc = if (e != null) findDocument(context, rootUri, e.uri) else null; if (doc != null && textValue.isNotBlank()) { status = if (doc.renameTo(textValue.trim())) "Renamed successfully" else "Rename failed"; refresh(folder) }; selected = null }
                        "delete" -> { val e = selected; val doc = if (e != null) findDocument(context, rootUri, e.uri) else null; if (doc != null) { status = if (doc.delete()) "Deleted successfully" else "Delete failed"; refresh(folder) }; selected = null }
                    }; dialog = ""
                }) { Text(if (dialog == "delete") "Delete" else "Save", color = if (dialog == "delete") Color(0xFFFF8A9A) else accent) } },
                dismissButton = { TextButton(onClick = { dialog = ""; selected = null }) { Text("Cancel", color = Muted) } })
        }
    }
}

@Composable
private fun FileRow(entry: Entry, accent: Color, compact: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    val icon = fileIcon(entry)
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x332D223D)), modifier = Modifier.fillMaxWidth().clickable(onClick = onClick).animateContentSize()) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = if (compact) 7.dp else 11.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(if (compact) 38.dp else 46.dp).clip(RoundedCornerShape(14.dp)).background(Glass), contentAlignment = Alignment.Center) { Icon(icon, null, tint = accent) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(entry.name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (entry.directory) "Folder" else "${humanSize(entry.size)}  ·  ${DateFormat.getDateInstance(DateFormat.SHORT).format(Date(entry.modified))}", color = Muted, style = MaterialTheme.typography.bodySmall, maxLines = 1)
            }
            IconButton(onClick = onLongClick) { Icon(Icons.Default.MoreVert, "More actions", tint = Muted) }
        }
    }
}

@Composable
private fun FileTile(entry: Entry, accent: Color, onClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth().height(130.dp).clickable(onClick = onClick)) {
        Column(Modifier.fillMaxSize().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(fileIcon(entry), null, tint = accent, modifier = Modifier.size(36.dp)); Spacer(Modifier.height(8.dp))
            Text(entry.name, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(if (entry.directory) "Folder" else humanSize(entry.size), color = Muted, style = MaterialTheme.typography.labelSmall)
        }
    }
}

private fun fileIcon(e: Entry) = when {
    e.directory -> Icons.Default.Folder
    e.mime?.startsWith("audio/") == true -> Icons.Default.MusicNote
    e.mime?.startsWith("video/") == true -> Icons.Default.PlayCircle
    e.mime?.startsWith("image/") == true -> Icons.Default.Image
    e.mime?.contains("pdf") == true -> Icons.Default.PictureAsPdf
    else -> Icons.Default.InsertDriveFile
}

private fun openFile(context: android.content.Context, entry: Entry) {
    try { context.startActivity(Intent(Intent.ACTION_VIEW).apply { setDataAndType(entry.uri, entry.mime ?: "*/*"); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }) }
    catch (_: Exception) { android.widget.Toast.makeText(context, "No compatible app found", android.widget.Toast.LENGTH_SHORT).show() }
}

private suspend fun loadEntries(folder: DocumentFile?): List<Entry> = withContext(Dispatchers.IO) {
    try { folder?.listFiles()?.map { f -> Entry(f.name ?: "Unnamed", f.uri, f.isDirectory, f.length(), f.lastModified(), if (f.isDirectory) null else f.type) } ?: emptyList() }
    catch (_: Exception) { emptyList() }
}

private fun findDocument(context: android.content.Context, root: Uri?, target: Uri): DocumentFile? {
    if (root == null) return null
    fun walk(folder: DocumentFile, depth: Int): DocumentFile? {
        if (folder.uri == target) return folder
        if (depth > 20) return null
        for (child in try { folder.listFiles() } catch (_: Exception) { emptyArray() }) {
            if (child.uri == target) return child
            if (child.isDirectory) { val found = walk(child, depth + 1); if (found != null) return found }
        }
        return null
    }
    return try { walk(DocumentFile.fromTreeUri(context, root) ?: return null, 0) } catch (_: Exception) { null }
}

private fun humanSize(size: Long): String {
    if (size < 0L) return "Unknown size"
    if (size == 0L) return "0 B"
    val units = listOf("B", "KB", "MB", "GB", "TB"); var value = size.toDouble(); var i = 0
    while (value >= 1024 && i < units.lastIndex) { value /= 1024; i++ }
    return String.format("%.1f %s", value, units[i])
}
