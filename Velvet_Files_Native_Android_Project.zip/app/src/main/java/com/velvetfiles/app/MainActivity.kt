package com.velvetfiles.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

private val Ink = Color(0xFF08060D)
private val Panel = Color(0xFF17111F)
private val Panel2 = Color(0xFF21172C)
private val Purple = Color(0xFFB66CFF)
private val Muted = Color(0xFFB7A9C8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VelvetApp() }
    }
}

data class Entry(val name: String, val uri: Uri, val directory: Boolean, val size: Long, val modified: Long, val mime: String?)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VelvetApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var rootUri by remember { mutableStateOf<Uri?>(null) }
    var entries by remember { mutableStateOf<List<Entry>>(emptyList()) }
    var currentFolder by remember { mutableStateOf<DocumentFile?>(null) }
    var pathTitle by remember { mutableStateOf("Your files") }
    var search by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf("Name · A–Z") }
    var sortMenu by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var grid by remember { mutableStateOf(false) }
    var accent by remember { mutableStateOf(Purple) }
    var blurGlow by remember { mutableStateOf(true) }
    var compact by remember { mutableStateOf(false) }
    var motion by remember { mutableStateOf(true) }
    var selected by remember { mutableStateOf<Entry?>(null) }
    var status by remember { mutableStateOf("Choose a folder to browse real files on your device.") }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                )
            } catch (_: Exception) {}
            rootUri = uri
            currentFolder = DocumentFile.fromTreeUri(context, uri)
            pathTitle = currentFolder?.name ?: "Your files"
            status = "Folder access granted"
            scope.launch {
                entries = loadEntries(currentFolder)
            }
        }
    }

    val filtered = entries.filter { it.name.contains(search, ignoreCase = true) }
    val sorted = when (sort) {
        "Name · Z–A" -> filtered.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name }.reversed())
        "Newest first" -> filtered.sortedByDescending { it.modified }
        "Oldest first" -> filtered.sortedBy { it.modified }
        "Largest first" -> filtered.sortedByDescending { it.size }
        "Smallest first" -> filtered.sortedBy { it.size }
        "Folders first" -> filtered.sortedWith(compareBy<Entry> { !it.directory }.thenBy(String.CASE_INSENSITIVE_ORDER) { it.name })
        else -> filtered.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = accent, onPrimary = Color.Black, background = Ink, surface = Panel,
            onBackground = Color.White, onSurface = Color.White, secondary = accent
        )
    ) {
        Scaffold(containerColor = Ink, floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { folderPicker.launch(rootUri) },
                containerColor = accent, contentColor = Color.Black,
                icon = { Icon(Icons.Default.FolderOpen, contentDescription = null) },
                text = { Text(if (rootUri == null) "Choose folder" else "Change folder") }
            )
        }) { padding ->
            Column(
                Modifier.fillMaxSize().background(Ink).padding(padding).padding(horizontal = 18.dp)
            ) {
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                    Box(Modifier.size(48.dp).clip(RoundedCornerShape(17.dp)).background(Panel2), contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.FolderSpecial, null, tint = accent, modifier = Modifier.size(29.dp))
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("VELVET FILES", color = Color.White, fontWeight = FontWeight.Black, style = MaterialTheme.typography.titleLarge)
                        Text("LIQUID EDITION  ·  NATIVE", color = accent, style = MaterialTheme.typography.labelSmall)
                    }
                    IconButton(onClick = { settings = !settings }) {
                        Icon(Icons.Default.Tune, "Customize", tint = accent)
                    }
                }
                Spacer(Modifier.height(20.dp))
                if (settings) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Panel),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier.fillMaxWidth().animateContentSize()
                    ) {
                        Column(Modifier.padding(16.dp)) {
                            Text("VELVET LAB", color = accent, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(10.dp))
                            Text("Accent color", color = Muted)
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(vertical = 10.dp)) {
                                listOf(Purple, Color(0xFF55E7FF), Color(0xFFFF75B7), Color(0xFFB9FF69), Color(0xFFFFC45C)).forEach { color ->
                                    Box(
                                        Modifier.size(34.dp).clip(RoundedCornerShape(50)).background(color)
                                            .clickable { accent = color },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (accent == color) Icon(Icons.Default.Check, null, tint = Color.Black)
                                    }
                                }
                            }
                            SettingRow("Ambient glow", blurGlow) { blurGlow = it }
                            SettingRow("Smooth animations", motion) { motion = it }
                            SettingRow("Compact rows", compact) { compact = it }
                            Text("Changes apply instantly. More settings can be added here.", color = Muted, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                }
                Card(colors = CardDefaults.cardColors(containerColor = if (blurGlow) Panel2 else Panel), shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text(pathTitle, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("${entries.size} items  ·  $status", color = Muted, style = MaterialTheme.typography.bodySmall, maxLines = 2)
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = search, onValueChange = { search = it },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                            placeholder = { Text("Search this folder…") },
                            leadingIcon = { Icon(Icons.Default.Search, null) },
                            shape = RoundedCornerShape(16.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = accent, unfocusedBorderColor = Color(0xFF43364F),
                                focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                                focusedContainerColor = Ink, unfocusedContainerColor = Ink
                            )
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box {
                                TextButton(onClick = { sortMenu = true }) {
                                    Icon(Icons.Default.Sort, null, tint = accent)
                                    Spacer(Modifier.width(6.dp))
                                    Text(sort, color = Color.White)
                                }
                                DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                                    listOf("Name · A–Z", "Name · Z–A", "Newest first", "Oldest first", "Largest first", "Smallest first", "Folders first").forEach {
                                        DropdownMenuItem(text = { Text(it) }, onClick = { sort = it; sortMenu = false })
                                    }
                                }
                            }
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = { grid = false }) { Icon(Icons.Default.ViewList, null, tint = if (!grid) accent else Muted) }
                            IconButton(onClick = { grid = true }) { Icon(Icons.Default.GridView, null, tint = if (grid) accent else Muted) }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                if (rootUri == null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.FolderOpen, null, tint = accent, modifier = Modifier.size(64.dp))
                            Spacer(Modifier.height(12.dp))
                            Text("Your files, your atmosphere.", color = Color.White, fontWeight = FontWeight.Bold)
                            Text("Pick a folder to grant Velvet Files access.", color = Muted)
                        }
                    }
                } else if (sorted.isEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text(if (search.isBlank()) "This folder is empty." else "No matching files.", color = Muted)
                    }
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 100.dp)) {
                        items(sorted, key = { it.uri.toString() }) { entry ->
                            FileRow(entry, accent, compact, grid, onClick = {
                                if (entry.directory) {
                                    currentFolder = DocumentFile.fromSingleUri(context, entry.uri)
                                    // DocumentFile.fromSingleUri cannot enumerate folders; resolve children from the selected tree URI.
                                    val doc = findDocument(context, rootUri, entry.uri)
                                    if (doc != null) {
                                        currentFolder = doc
                                        pathTitle = doc.name ?: entry.name
                                        scope.launch { entries = loadEntries(doc) }
                                    }
                                } else {
                                    selected = entry
                                    val intent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(entry.uri, entry.mime ?: "*/*")
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    try { context.startActivity(intent) } catch (_: Exception) {
                                        status = "No app found to open this file"
                                    }
                                }
                            })
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun FileRow(entry: Entry, accent: Color, compact: Boolean, grid: Boolean, onClick: () -> Unit) {
    val icon = when {
        entry.directory -> Icons.Default.Folder
        entry.mime?.startsWith("audio/") == true -> Icons.Default.MusicNote
        entry.mime?.startsWith("video/") == true -> Icons.Default.PlayCircle
        entry.mime?.startsWith("image/") == true -> Icons.Default.Image
        else -> Icons.Default.InsertDriveFile
    }
    Card(
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = if (compact) 8.dp else 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(if (compact) 38.dp else 46.dp).clip(RoundedCornerShape(14.dp)).background(Panel2), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = accent)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(entry.name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (entry.directory) "Folder" else "${humanSize(entry.size)}  ·  ${entry.mime ?: "File"}", color = Muted, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Icon(Icons.Default.ChevronRight, null, tint = Muted)
        }
    }
}

private suspend fun loadEntries(folder: DocumentFile?): List<Entry> = withContext(Dispatchers.IO) {
    folder?.listFiles()?.map { file ->
        Entry(
            name = file.name ?: "Unnamed",
            uri = file.uri,
            directory = file.isDirectory,
            size = file.length(),
            modified = file.lastModified(),
            mime = if (file.isDirectory) null else file.type
        )
    } ?: emptyList()
}

private fun findDocument(context: android.content.Context, root: Uri?, target: Uri): DocumentFile? {
    if (root == null) return null
    fun walk(folder: DocumentFile): DocumentFile? {
        if (folder.uri == target) return folder
        val children = try { folder.listFiles() } catch (_: Exception) { emptyArray() }
        for (child in children) {
            if (child.uri == target) return child
            if (child.isDirectory) {
                val found = walk(child)
                if (found != null) return found
            }
        }
        return null
    }
    return try { walk(DocumentFile.fromTreeUri(context, root) ?: return null) } catch (_: Exception) { null }
}

private fun humanSize(size: Long): String {
    if (size <= 0L) return "Size unknown"
    val units = listOf("B", "KB", "MB", "GB", "TB")
    var value = size.toDouble()
    var unit = 0
    while (value >= 1024 && unit < units.lastIndex) { value /= 1024; unit++ }
    return String.format("%.1f %s", value, units[unit])
}
