# Velvet Files — Native Android starter

This is an Android Studio Kotlin + Jetpack Compose project, not a web app wrapper.

## Features in this starter
- Native dark AMOLED-inspired interface with purple liquid-glass styling
- Accent color selector and appearance toggles
- Choose a real folder using Android's Storage Access Framework
- Browse folder contents, search, numeric-aware name sorting, date and size sorting
- Open files with installed Android apps (including audio/video players)
- List/grid control and compact rows

## Build an APK
1. Install Android Studio and its Android SDK (API 35 or compatible).
2. Open this folder in Android Studio.
3. Let Gradle sync and install any requested SDK components.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. For a distributable release, use **Build > Generate Signed Bundle / APK**.

## Notes
- The project requires internet access the first time Gradle downloads dependencies.
- Android Studio's bundled JDK is recommended.
- Folder access is granted by the user through Android's folder picker. This avoids requesting broad all-files access.
- File opening is delegated to compatible apps installed on the device.
- This is a functional starter, not a fully production-tested Play Store app. Test folder navigation and behavior on your Android version before relying on it.
