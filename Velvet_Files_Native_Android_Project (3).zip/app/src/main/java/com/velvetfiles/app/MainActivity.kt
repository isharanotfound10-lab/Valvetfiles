package com.velvetfiles.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.ThumbnailUtils
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.provider.MediaStore
import android.util.Size
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date
import android.os.StatFs
import android.widget.Toast

private data class ThemePreset(
    val name: String,
    val background: Color,
    val panel: Color,
    val panelLight: Color,
    val glass: Color,
    val accent: Color,
    val secondary: Color,
    val muted: Color,
    val border: Color
)

private val ThemePresets = listOf(
    ThemePreset("Liquid Glass", Color(0xFF05040A), Color(0xFF111019), Color(0xFF191522), Color(0xB8211A30), Color(0xFFBD7BFF), Color(0xFF70E5FF), Color(0xFFB7ADC8), Color(0x554D3B67)),
    ThemePreset("Arctic Aurora", Color(0xFF061019), Color(0xFF0D1C28), Color(0xFF142B3A), Color(0xB8173848), Color(0xFF65E7FF), Color(0xFF9EAFFF), Color(0xFFAFC7D7), Color(0x554D8AA0)),
    ThemePreset("Rose Quartz", Color(0xFF140710), Color(0xFF21101C), Color(0xFF301728), Color(0xB83B1733), Color(0xFFFF7DB7), Color(0xFFFFC6E1), Color(0xFFD8B4C8), Color(0x665E2947)),
    ThemePreset("Emerald Hologram", Color(0xFF030E0B), Color(0xFF0A1914), Color(0xFF102720), Color(0xB8224C3D), Color(0xFF70F0C0), Color(0xFFB7F68A), Color(0xFFAECFC1), Color(0x55407A66)),
    ThemePreset("Sunset Prism", Color(0xFF130A14), Color(0xFF24131F), Color(0xFF31192A), Color(0xB83A1C30), Color(0xFFFF9B73), Color(0xFFFFD166), Color(0xFFD8B9C6), Color(0x665E344A)),
    ThemePreset("Pure AMOLED", Color(0xFF000000), Color(0xFF090909), Color(0xFF111111), Color(0x99191919), Color(0xFFFFFFFF), Color(0xFFA6C8FF), Color(0xFFB8B8B8), Color(0x553D3D3D))
)
private val ActiveTheme = mutableStateOf(ThemePresets.first())
private val Ink: Color get() = ActiveTheme.value.background
private val Panel: Color get() = ActiveTheme.value.panel
private val PanelLight: Color get() = ActiveTheme.value.panelLight
private val Glass: Color get() = ActiveTheme.value.glass
private val Purple: Color get() = ActiveTheme.value.accent
private val Cyan: Color get() = ActiveTheme.value.secondary
private val Muted: Color get() = ActiveTheme.value.muted
private val Border: Color get() = ActiveTheme.value.border
private fun themeByName(name: String): ThemePreset = ThemePresets.firstOrNull { it.name == name } ?: ThemePresets.first()
private val RootStorage: File get() = Environment.getExternalStorageDirectory()

class MainActivity : ComponentActivity() {
    private var hasStorageAccess by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        hasStorageAccess = storagePermissionGranted(this)
        setContent {
            FileManagerApp(
                hasStorageAccess = hasStorageAccess,
                requestStorageAccess = { requestStoragePermission() }
            )
        }
    }

    override fun onResume() {
        super.onResume()
        hasStorageAccess = storagePermissionGranted(this)
    }

    private fun requestStoragePermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                    data = Uri.fromParts("package", packageName, null)
                })
            } catch (_: Exception) {
                try { startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
                catch (_: Exception) { Toast.makeText(this, "Open Settings and allow all-files access for File Manager", Toast.LENGTH_LONG).show() }
            }
        } else {
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 1402)
        }
    }
}

private data class FileEntry(val file: File) {
    val name: String get() = file.name.ifBlank { file.absolutePath }
    val directory: Boolean get() = file.isDirectory
    val size: Long get() = if (file.isFile) file.length() else 0L
    val modified: Long get() = file.lastModified()
    val mime: String? get() = mimeType(file)
}

private fun storagePermissionGranted(context: Context): Boolean = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
    Environment.isExternalStorageManager()
} else {
    ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FileManagerApp(hasStorageAccess: Boolean, requestStorageAccess: () -> Unit) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("file_manager_preferences", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    var screen by remember { mutableStateOf("home") } // home, browse, recent, category, search, settings
    var themeName by remember { mutableStateOf(prefs.getString("theme_name", "Liquid Glass") ?: "Liquid Glass") }
    var showHiddenFiles by remember { mutableStateOf(prefs.getBoolean("show_hidden_files", false)) }
    var category by remember { mutableStateOf("Images") }
    var currentFolder by remember { mutableStateOf(RootStorage) }
    var folderStack by remember { mutableStateOf(listOf(RootStorage)) }
    var entries by remember { mutableStateOf<List<FileEntry>>(emptyList()) }
    var recents by remember { mutableStateOf<List<FileEntry>>(emptyList()) }
    var homeSearch by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf("Name · A–Z") }
    var sortMenu by remember { mutableStateOf(false) }
    var grid by remember { mutableStateOf(prefs.getBoolean("grid_layout", false)) }
    var compact by remember { mutableStateOf(prefs.getBoolean("compact_rows", false)) }
    var accent by remember { mutableStateOf(themeByName(themeName).accent) }
    var selected by remember { mutableStateOf<FileEntry?>(null) }
    var actionDialog by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf("") }
    var textValue by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("") }
    var pendingTransfer by remember { mutableStateOf<File?>(null) }
    var pendingMove by remember { mutableStateOf(false) }
    var refreshKey by remember { mutableIntStateOf(0) }

    LaunchedEffect(themeName) {
        val chosen = themeByName(themeName)
        ActiveTheme.value = chosen
        accent = chosen.accent
    }

    fun chooseTheme(theme: ThemePreset) {
        themeName = theme.name
        prefs.edit().putString("theme_name", theme.name).apply()
        ActiveTheme.value = theme
        accent = theme.accent
    }
    fun setCompactRows(value: Boolean) {
        compact = value
        prefs.edit().putBoolean("compact_rows", value).apply()
    }
    fun setShowHidden(value: Boolean) {
        showHiddenFiles = value
        prefs.edit().putBoolean("show_hidden_files", value).apply()
        refreshKey++
    }
    fun setGridLayout(value: Boolean) {
        grid = value
        prefs.edit().putBoolean("grid_layout", value).apply()
    }

    fun goHome() { screen = "home"; search = ""; homeSearch = "" }
    fun goBrowse(folder: File = RootStorage) {
        currentFolder = folder
        folderStack = if (folder.absolutePath == RootStorage.absolutePath) listOf(RootStorage) else {
            val path = folder.absoluteFile.toPath()
            val items = mutableListOf<File>()
            var node: File? = folder
            while (node != null && node.absolutePath.startsWith(RootStorage.absolutePath)) { items.add(node); if (node.absolutePath == RootStorage.absolutePath) break; node = node.parentFile }
            if (items.lastOrNull()?.absolutePath != RootStorage.absolutePath) items.add(RootStorage)
            items.asReversed()
        }
        screen = "browse"
        search = ""
    }

    LaunchedEffect(hasStorageAccess, screen, currentFolder.absolutePath, category, refreshKey, showHiddenFiles) {
        if (!hasStorageAccess) return@LaunchedEffect
        status = "Loading…"
        val loaded = withContext(Dispatchers.IO) {
            when (screen) {
                "browse" -> listDirectory(currentFolder, showHiddenFiles)
                "recent" -> scanFiles(RootStorage, maxDepth = 5, maxDirectories = 550, showHidden = showHiddenFiles).sortedByDescending { it.modified }.take(300)
                "category" -> scanFiles(RootStorage, maxDepth = 6, maxDirectories = 800, showHidden = showHiddenFiles).filter { inCategory(it.file, category) }
                "search" -> scanFiles(RootStorage, maxDepth = 6, maxDirectories = 900, showHidden = showHiddenFiles)
                else -> emptyList()
            }
        }
        entries = loaded
        if (screen == "home") recents = withContext(Dispatchers.IO) {
            scanFiles(RootStorage, maxDepth = 4, maxDirectories = 350, showHidden = showHiddenFiles).sortedByDescending { it.modified }.take(8)
        }
        status = "${loaded.size} items"
    }

    val filtered = entries.filter { it.name.contains(search, ignoreCase = true) }
    val sorted = when (sort) {
        "Name · Z–A" -> filtered.sortedByDescending { it.name.lowercase() }
        "Newest first" -> filtered.sortedByDescending { it.modified }
        "Oldest first" -> filtered.sortedBy { it.modified }
        "Largest first" -> filtered.sortedByDescending { it.size }
        "Smallest first" -> filtered.sortedBy { it.size }
        "Files first" -> filtered.sortedWith(compareBy<FileEntry> { it.directory }.thenBy { it.name.lowercase() })
        else -> filtered.sortedWith(compareBy<FileEntry> { !it.directory }.thenBy { it.name.lowercase() })
    }

    fun openEntry(entry: FileEntry) {
        if (entry.directory) goBrowse(entry.file) else openFile(context, entry.file)
    }
    fun refresh() { refreshKey++ }
    fun pasteIntoCurrentFolder() {
        val source = pendingTransfer ?: return
        scope.launch {
            val result = withContext(Dispatchers.IO) {
                val dest = File(currentFolder, source.name)
                if (!source.exists()) "The original item no longer exists"
                else if (dest.exists()) "An item with that name already exists here"
                else if (source.isDirectory && dest.absolutePath.startsWith(source.absolutePath + File.separator)) "Cannot copy or move a folder into itself"
                else try {
                    if (pendingMove) {
                        val moved = source.renameTo(dest) || (source.copyRecursively(dest, overwrite = false) && source.deleteRecursively())
                        if (moved) "Moved successfully" else "Move failed"
                    } else {
                        if (source.copyRecursively(dest, overwrite = false)) "Copied successfully" else "Copy failed"
                    }
                } catch (e: Exception) { "Operation failed: ${e.message ?: "unknown error"}" }
            }
            status = result
            if (result.endsWith("successfully")) pendingTransfer = null
            refresh()
            Toast.makeText(context, result, Toast.LENGTH_SHORT).show()
        }
    }

    BackHandler(enabled = hasStorageAccess && screen != "home") {
        when (screen) {
            "browse" -> if (folderStack.size > 1) {
                folderStack = folderStack.dropLast(1)
                currentFolder = folderStack.last()
                search = ""
            } else goHome()
            else -> goHome()
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = accent, secondary = Cyan, background = Ink, surface = Panel, onSurface = Color.White, onBackground = Color.White)) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                if (hasStorageAccess) {
                    NavigationBar(containerColor = Panel.copy(alpha = .96f), contentColor = accent, tonalElevation = 0.dp) {
                        NavigationBarItem(selected = screen == "home", onClick = { goHome() }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") }, colors = NavigationBarItemDefaults.colors(selectedIconColor = accent, selectedTextColor = accent, indicatorColor = Glass))
                        NavigationBarItem(selected = screen == "browse", onClick = { goBrowse() }, icon = { Icon(Icons.Default.FolderOpen, null) }, label = { Text("Browse") }, colors = NavigationBarItemDefaults.colors(selectedIconColor = accent, selectedTextColor = accent, indicatorColor = Glass))
                        NavigationBarItem(selected = screen == "recent", onClick = { screen = "recent"; search = "" }, icon = { Icon(Icons.Default.History, null) }, label = { Text("Recent") }, colors = NavigationBarItemDefaults.colors(selectedIconColor = accent, selectedTextColor = accent, indicatorColor = Glass))
                        NavigationBarItem(selected = screen == "settings", onClick = { screen = "settings" }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") }, colors = NavigationBarItemDefaults.colors(selectedIconColor = accent, selectedTextColor = accent, indicatorColor = Glass))
                    }
                }
            },
            floatingActionButton = {
                if (hasStorageAccess && screen == "browse") {
                    FloatingActionButton(onClick = { dialog = "create"; textValue = "" }, containerColor = accent, contentColor = Ink, shape = RoundedCornerShape(20.dp)) { Icon(Icons.Default.CreateNewFolder, "Create folder") }
                }
            }
        ) { scaffoldPadding ->
            if (!hasStorageAccess) {
                PermissionScreen(onGrant = requestStorageAccess)
            } else if (screen == "home") {
                HomeScreen(
                    accent = accent,
                    query = homeSearch,
                    onQueryChange = { homeSearch = it },
                    onSearch = { search = homeSearch; screen = "search" },
                    recents = recents,
                    compact = compact,
                    onSettings = { screen = "settings" },
                    onBrowse = { goBrowse() },
                    onRecent = { screen = "recent"; search = "" },
                    onCategory = { label -> category = label; search = ""; grid = label == "Images" || label == "Videos"; screen = "category" },
                    onOpen = { openEntry(it) },
                    modifier = Modifier.padding(scaffoldPadding)
                )
            } else if (screen == "settings") {
                SettingsScreen(
                    currentTheme = themeName,
                    onThemeSelected = { chooseTheme(it) },
                    compactRows = compact,
                    onCompactRows = { setCompactRows(it) },
                    showHiddenFiles = showHiddenFiles,
                    onShowHiddenFiles = { setShowHidden(it) },
                    gridLayout = grid,
                    onGridLayout = { setGridLayout(it) },
                    onBack = { goHome() },
                    modifier = Modifier.padding(scaffoldPadding)
                )
            } else {
                Column(Modifier.fillMaxSize().background(Ink).padding(scaffoldPadding).padding(horizontal = 16.dp)) {
                    Spacer(Modifier.height(12.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                        IconButton(onClick = {
                            if (screen == "browse" && folderStack.size > 1) { folderStack = folderStack.dropLast(1); currentFolder = folderStack.last(); search = "" } else goHome()
                        }) { Icon(Icons.Default.ArrowBack, "Back", tint = accent) }
                        Column(Modifier.weight(1f)) {
                            Text(when (screen) { "browse" -> currentFolder.name.ifBlank { "Internal storage" }; "recent" -> "Recent"; "category" -> category; else -> "Search results" }, color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(if (screen == "browse") currentFolder.absolutePath else status, color = Muted, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (screen == "browse" && pendingTransfer != null) {
                            IconButton(onClick = { pasteIntoCurrentFolder() }) { Icon(Icons.Default.ContentPaste, "Paste ${pendingTransfer?.name}", tint = accent) }
                        }
                        IconButton(onClick = { setGridLayout(!grid) }) { Icon(if (grid) Icons.Default.ViewList else Icons.Default.GridView, "Change layout", tint = accent) }
                        Box {
                            IconButton(onClick = { sortMenu = true }) { Icon(Icons.Default.Sort, "Sort", tint = accent) }
                            DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }, containerColor = PanelLight) {
                                listOf("Folders first", "Files first", "Name · A–Z", "Name · Z–A", "Newest first", "Oldest first", "Largest first", "Smallest first").forEach { option ->
                                    DropdownMenuItem(text = { Text(option, color = Color.White) }, onClick = { sort = option; sortMenu = false })
                                }
                            }
                        }
                    }
                    if (screen == "browse" || screen == "category" || screen == "recent" || screen == "search") {
                        GlassSearchField(value = search, onValueChange = { search = it }, accent = accent, onSearch = {})
                    }
                    if (screen == "browse" && pendingTransfer != null) {
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Glass).clickable { pasteIntoCurrentFolder() }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ContentPaste, null, tint = accent); Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) { Text("${if (pendingMove) "Move" else "Copy"} ${pendingTransfer?.name}", color = Color.White, fontWeight = FontWeight.SemiBold); Text("Tap to paste into this folder", color = Muted, style = MaterialTheme.typography.labelSmall) }
                            TextButton(onClick = { pendingTransfer = null }) { Text("Cancel", color = Muted) }
                        }
                        Spacer(Modifier.height(8.dp))
                    }
                    if (sorted.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(if (screen == "browse") Icons.Default.FolderOff else Icons.Default.SearchOff, null, tint = Muted, modifier = Modifier.size(44.dp))
                                Spacer(Modifier.height(8.dp)); Text(if (status == "Loading…") "Loading files…" else if (search.isNotBlank()) "No matching files" else "Nothing here yet", color = Muted)
                                if (screen == "browse") Text("Storage: ${currentFolder.absolutePath}", color = Muted, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    } else if (grid) {
                        LazyVerticalGrid(columns = GridCells.Adaptive(145.dp), contentPadding = PaddingValues(top = 8.dp, bottom = 90.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            gridItems(sorted, key = { it.file.absolutePath }) { e -> FileTile(e, accent, onClick = { openEntry(e) }, onLongClick = { selected = e; actionDialog = true }) }
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(top = 8.dp, bottom = 90.dp)) {
                            items(sorted, key = { it.file.absolutePath }) { e -> FileRow(e, accent, compact, onClick = { openEntry(e) }, onLongClick = { selected = e; actionDialog = true }) }
                        }
                    }
                }
            }
        }

        if (actionDialog && selected != null) {
            val entry = selected!!
            AlertDialog(
                onDismissRequest = { actionDialog = false }, containerColor = PanelLight,
                title = { Text(entry.name, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                text = { Text(if (entry.directory) "Folder · ${entry.file.absolutePath}" else "${humanSize(entry.size)} · ${DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(entry.modified))}", color = Muted) },
                confirmButton = {
                    Column(horizontalAlignment = Alignment.End) {
                        Row {
                            TextButton(onClick = { openEntry(entry); actionDialog = false }) { Text("Open", color = accent) }
                            TextButton(onClick = { shareFile(context, entry.file); actionDialog = false }) { Text("Share", color = accent) }
                        }
                        Row {
                            TextButton(onClick = { textValue = entry.name; dialog = "rename"; actionDialog = false }) { Text("Rename", color = accent) }
                            TextButton(onClick = { pendingTransfer = entry.file; pendingMove = false; actionDialog = false; status = "Ready to copy — browse to the destination and tap Paste" }) { Text("Copy", color = accent) }
                            TextButton(onClick = { pendingTransfer = entry.file; pendingMove = true; actionDialog = false; status = "Ready to move — browse to the destination and tap Paste" }) { Text("Move", color = accent) }
                        }
                        TextButton(onClick = { dialog = "delete"; actionDialog = false }) { Text("Delete", color = Color(0xFFFF8A9A)) }
                    }
                },
                dismissButton = { TextButton(onClick = { actionDialog = false; selected = null }) { Text("Cancel", color = Muted) } }
            )
        }

        if (dialog == "create" || dialog == "rename" || dialog == "delete") {
            AlertDialog(
                onDismissRequest = { val oldDialog = dialog; dialog = ""; if (oldDialog != "create") selected = null },
                containerColor = PanelLight,
                title = { Text(when (dialog) { "create" -> "New folder"; "rename" -> "Rename item"; else -> "Delete item?" }, color = Color.White) },
                text = {
                    if (dialog == "delete") Text("Delete ${selected?.name ?: "this item"}? This cannot be undone.", color = Muted)
                    else OutlinedTextField(value = textValue, onValueChange = { textValue = it }, singleLine = true, label = { Text("Name") }, colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = accent, focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedLabelColor = accent))
                },
                confirmButton = { TextButton(onClick = {
                    scope.launch {
                        val result = withContext(Dispatchers.IO) {
                            try {
                                when (dialog) {
                                    "create" -> if (textValue.isNotBlank() && File(currentFolder, textValue.trim()).mkdir()) "Folder created" else "Could not create folder"
                                    "rename" -> {
                                        val file = selected?.file
                                        val newName = textValue.trim()
                                        if (file != null && newName.isNotBlank() && !File(file.parentFile, newName).exists() && file.renameTo(File(file.parentFile, newName))) "Renamed successfully" else "Rename failed"
                                    }
                                    else -> if (selected?.file?.deleteRecursively() == true) "Deleted successfully" else "Delete failed"
                                }
                            } catch (e: Exception) { "Operation failed: ${e.message ?: "unknown error"}" }
                        }
                        status = result; Toast.makeText(context, result, Toast.LENGTH_SHORT).show(); selected = null; dialog = ""; refresh()
                    }
                }) { Text(if (dialog == "delete") "Delete" else "Save", color = if (dialog == "delete") Color(0xFFFF8A9A) else accent) } },
                dismissButton = { TextButton(onClick = { dialog = ""; selected = null }) { Text("Cancel", color = Muted) } }
            )
        }
    }
}

@Composable
private fun PermissionScreen(onGrant: () -> Unit) {
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF100B1B), Ink, Color.Black))).padding(28.dp), horizontalAlignment = Alignment.Start, verticalArrangement = Arrangement.Center) {
        Box(Modifier.size(82.dp).clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Purple.copy(alpha = .35f), Cyan.copy(alpha = .16f)))).then(Modifier), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.FolderSpecial, null, tint = Purple, modifier = Modifier.size(46.dp))
        }
        Spacer(Modifier.height(28.dp))
        Text("Your files.\nYour way.", color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(12.dp))
        Text("A Google Files-inspired file manager with an AMOLED liquid-glass look.", color = Muted, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(22.dp))
        GlassPanel {
            Row(verticalAlignment = Alignment.Top) {
                Icon(Icons.Default.Security, null, tint = Cyan, modifier = Modifier.padding(top = 2.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Allow access to manage all files", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text("Android opens a system Settings page. Enable the permission to browse shared internal storage without choosing a folder every time.", color = Muted, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        Button(onClick = onGrant, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(18.dp), colors = ButtonDefaults.buttonColors(containerColor = Purple, contentColor = Ink)) {
            Icon(Icons.Default.FolderOpen, null); Spacer(Modifier.width(10.dp)); Text("Grant storage access", fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        Text("This accesses shared storage only. Android still restricts some protected app folders, especially Android/data.", color = Muted, style = MaterialTheme.typography.labelSmall)
    }
}

@Composable
private fun HomeScreen(
    accent: Color, query: String, onQueryChange: (String) -> Unit, onSearch: () -> Unit,
    recents: List<FileEntry>, compact: Boolean, onSettings: () -> Unit, onBrowse: () -> Unit,
    onRecent: () -> Unit, onCategory: (String) -> Unit, onOpen: (FileEntry) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scroll = rememberScrollState()
    val storage = remember { storageStats() }
    Column(modifier.fillMaxSize().background(Brush.verticalGradient(listOf(PanelLight.copy(alpha = .82f), Ink, Ink))).verticalScroll(scroll).padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(18.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("File Manager", color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold)
                Text("Everything on your device", color = Muted, style = MaterialTheme.typography.bodyMedium)
            }
            Box(Modifier.size(48.dp).clip(RoundedCornerShape(17.dp)).background(Brush.linearGradient(listOf(accent.copy(alpha = .30f), Cyan.copy(alpha = .12f)))).clickable { onSettings() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Tune, "Appearance settings", tint = accent)
            }
        }
        Spacer(Modifier.height(16.dp))
        GlassSearchField(value = query, onValueChange = onQueryChange, accent = accent, onSearch = onSearch, hint = "Search files on this device")
        Spacer(Modifier.height(20.dp))
        Text("CATEGORIES", color = Muted, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CategoryCard("Images", "Photos and pictures", Icons.Default.Image, Color(0xFFFF83B7), Modifier.weight(1f)) { onCategory("Images") }
                CategoryCard("Videos", "Movies and clips", Icons.Default.PlayCircle, Color(0xFF8B9BFF), Modifier.weight(1f)) { onCategory("Videos") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CategoryCard("Audio", "Music and recordings", Icons.Default.MusicNote, Color(0xFF70E5FF), Modifier.weight(1f)) { onCategory("Audio") }
                CategoryCard("Documents", "PDFs and files", Icons.Default.Description, Color(0xFFFFC978), Modifier.weight(1f)) { onCategory("Documents") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CategoryCard("Downloads", "Downloaded items", Icons.Default.Download, accent, Modifier.weight(1f)) { onCategory("Downloads") }
                CategoryCard("Large files", "Files over 100 MB", Icons.Default.Storage, Color(0xFFB7F080), Modifier.weight(1f)) { onCategory("Large files") }
            }
        }
        Spacer(Modifier.height(20.dp))
        GlassPanel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(43.dp).clip(RoundedCornerShape(14.dp)).background(Glass), contentAlignment = Alignment.Center) { Icon(Icons.Default.PhoneAndroid, null, tint = accent) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Internal storage", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("${humanSize(storage.first)} used of ${humanSize(storage.second)}", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
                IconButton(onClick = onBrowse) { Icon(Icons.Default.ChevronRight, "Browse storage", tint = accent) }
            }
            Spacer(Modifier.height(12.dp))
            val progress = if (storage.second > 0) (storage.first.toFloat() / storage.second.toFloat()).coerceIn(0f, 1f) else 0f
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape), color = accent, trackColor = Color(0xFF2A2435))
            Spacer(Modifier.height(8.dp))
            Text("${(progress * 100).toInt()}% used", color = Muted, style = MaterialTheme.typography.labelSmall)
        }
        Spacer(Modifier.height(20.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Recent files", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onRecent) { Text("See all", color = accent) }
        }
        if (recents.isEmpty()) {
            Text("Files you open or download will show up here.", color = Muted, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 12.dp))
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                recents.take(6).forEach { entry -> FileRow(entry, accent, compact, onClick = { onOpen(entry) }, onLongClick = { onOpen(entry) }) }
            }
        }
        Spacer(Modifier.height(22.dp))
    }
}

@Composable
private fun SettingsScreen(
    currentTheme: String,
    onThemeSelected: (ThemePreset) -> Unit,
    compactRows: Boolean,
    onCompactRows: (Boolean) -> Unit,
    showHiddenFiles: Boolean,
    onShowHiddenFiles: (Boolean) -> Unit,
    gridLayout: Boolean,
    onGridLayout: (Boolean) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(PanelLight.copy(alpha = .95f), Ink, Ink)))
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 18.dp)
    ) {
        Spacer(Modifier.height(14.dp))
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = Purple) }
            Column(Modifier.weight(1f)) {
                Text("Settings", color = Color.White, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold)
                Text("Make File Manager yours", color = Muted, style = MaterialTheme.typography.bodySmall)
            }
            Icon(Icons.Default.Tune, null, tint = Purple, modifier = Modifier.size(28.dp))
        }
        Spacer(Modifier.height(18.dp))
        GlassPanel {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(Purple.copy(alpha = .5f), Cyan.copy(alpha = .22f)))), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Star, null, tint = Color.White)
                }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Liquid-glass themes", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Choose a whole look — backgrounds, glass panels and accents change together.", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
            }
            Spacer(Modifier.height(14.dp))
            ThemePresets.chunked(2).forEach { rowThemes ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    rowThemes.forEach { preset ->
                        val chosen = preset.name == currentTheme
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(18.dp))
                                .background(Brush.linearGradient(listOf(preset.glass, preset.panel, preset.background)))
                                .border(BorderStroke(if (chosen) 2.dp else 1.dp, if (chosen) preset.accent else preset.border), RoundedCornerShape(18.dp))
                                .clickable { onThemeSelected(preset) }
                                .padding(12.dp)
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.fillMaxWidth()) {
                                Box(Modifier.weight(1f).height(9.dp).clip(CircleShape).background(preset.accent))
                                Box(Modifier.weight(1f).height(9.dp).clip(CircleShape).background(preset.secondary))
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(preset.name, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(if (chosen) "Active theme" else "Preview theme", color = preset.muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f))
                                if (chosen) Icon(Icons.Default.CheckCircle, null, tint = preset.accent, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                    if (rowThemes.size == 1) Spacer(Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
            }
        }
        Spacer(Modifier.height(14.dp))
        GlassPanel {
            Text("FILE BROWSING", color = Purple, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(Glass), contentAlignment = Alignment.Center) { Icon(Icons.Default.GridView, null, tint = Purple) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Grid layout", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Bigger cards for visual browsing", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = gridLayout, onCheckedChange = onGridLayout, colors = SwitchDefaults.colors(checkedThumbColor = Ink, checkedTrackColor = Purple))
            }
            HorizontalDivider(color = Border)
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(Glass), contentAlignment = Alignment.Center) { Icon(Icons.Default.ViewList, null, tint = Cyan) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Compact file rows", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Fit more files on screen", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = compactRows, onCheckedChange = onCompactRows, colors = SwitchDefaults.colors(checkedThumbColor = Ink, checkedTrackColor = Purple))
            }
            HorizontalDivider(color = Border)
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                Box(Modifier.size(40.dp).clip(RoundedCornerShape(13.dp)).background(Glass), contentAlignment = Alignment.Center) { Icon(Icons.Default.Visibility, null, tint = Cyan) }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Show hidden files", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Include dot-prefixed files and folders", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = showHiddenFiles, onCheckedChange = onShowHiddenFiles, colors = SwitchDefaults.colors(checkedThumbColor = Ink, checkedTrackColor = Purple))
            }
        }
        Spacer(Modifier.height(14.dp))
        GlassPanel {
            Row(verticalAlignment = Alignment.Top) {
                Icon(Icons.Default.Security, null, tint = Cyan, modifier = Modifier.padding(top = 2.dp))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Storage access & privacy", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(5.dp))
                    Text("File Manager uses Android's all-files-access permission for shared storage. Android still protects certain app-private locations and restricted folders. Files stay on your device unless you choose to share them.", color = Muted, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun CategoryCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Column(modifier.clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(tint.copy(alpha = .25f), Glass, Panel))).border(BorderStroke(1.dp, tint.copy(alpha = .30f)), RoundedCornerShape(22.dp)).clickable(onClick = onClick).padding(14.dp).heightIn(min = 96.dp)) {
        Box(Modifier.size(38.dp).clip(RoundedCornerShape(13.dp)).background(tint.copy(alpha = .15f)), contentAlignment = Alignment.Center) { Icon(icon, null, tint = tint) }
        Spacer(Modifier.height(10.dp))
        Text(title, color = Color.White, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun GlassPanel(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Glass.copy(alpha = .76f), Panel.copy(alpha = .62f), PanelLight.copy(alpha = .70f)))).border(BorderStroke(1.dp, Border), RoundedCornerShape(24.dp)).padding(15.dp), content = content)
}

@Composable
private fun GlassSearchField(value: String, onValueChange: (String) -> Unit, accent: Color, onSearch: () -> Unit, hint: String = "Search in this folder") {
    OutlinedTextField(
        value = value, onValueChange = onValueChange, modifier = Modifier.fillMaxWidth(), singleLine = true,
        placeholder = { Text(hint, color = Muted) }, leadingIcon = { Icon(Icons.Default.Search, null, tint = accent) },
        trailingIcon = { IconButton(onClick = onSearch) { Icon(Icons.Default.ArrowForward, "Search", tint = accent) } },
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { onSearch() }),
        shape = RoundedCornerShape(18.dp), colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = accent.copy(alpha = .75f), unfocusedBorderColor = Border,
            focusedContainerColor = Glass, unfocusedContainerColor = Glass,
            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
            cursorColor = accent, focusedPlaceholderColor = Muted, unfocusedPlaceholderColor = Muted
        )
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileRow(entry: FileEntry, accent: Color, compact: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xCC121019)), shape = RoundedCornerShape(19.dp),
        border = BorderStroke(1.dp, Color(0x332F2642)), modifier = Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLongClick).animateContentSize()
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = if (compact) 6.dp else 10.dp), verticalAlignment = Alignment.CenterVertically) {
            FileThumbnail(entry, Modifier.size(if (compact) 42.dp else 54.dp), accent)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(entry.name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (entry.directory) "Folder" else "${humanSize(entry.size)}  ·  ${DateFormat.getDateInstance(DateFormat.SHORT).format(Date(entry.modified))}", color = Muted, style = MaterialTheme.typography.bodySmall, maxLines = 1)
            }
            IconButton(onClick = onLongClick) { Icon(Icons.Default.MoreVert, "More actions", tint = Muted) }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileTile(entry: FileEntry, accent: Color, onClick: () -> Unit, onLongClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Glass.copy(alpha = .78f)), shape = RoundedCornerShape(21.dp), border = BorderStroke(1.dp, Border), modifier = Modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLongClick)) {
        Column(Modifier.fillMaxWidth().padding(8.dp)) {
            FileThumbnail(entry, Modifier.fillMaxWidth().height(if (entry.directory) 76.dp else 116.dp), accent)
            Spacer(Modifier.height(9.dp))
            Text(entry.name, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 3.dp))
            Text(if (entry.directory) "Folder" else humanSize(entry.size), color = Muted, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(start = 3.dp, top = 2.dp, bottom = 3.dp))
        }
    }
}

@Composable
private fun FileThumbnail(entry: FileEntry, modifier: Modifier = Modifier, accent: Color = Purple) {
    val bitmap by produceState<Bitmap?>(initialValue = null, key1 = entry.file.absolutePath, key2 = entry.modified, key3 = entry.size) {
        value = if (entry.directory) null else withContext(Dispatchers.IO) { createThumbnail(entry.file) }
    }
    Box(modifier.clip(RoundedCornerShape(14.dp)).background(Brush.linearGradient(listOf(accent.copy(alpha = .26f), Glass, Panel))), contentAlignment = Alignment.Center) {
        if (bitmap != null) {
            Image(bitmap = bitmap!!.asImageBitmap(), contentDescription = entry.name, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            if (isVideoFile(entry.file)) {
                Box(Modifier.align(Alignment.BottomEnd).padding(4.dp).size(24.dp).clip(CircleShape).background(Color.Black.copy(alpha = .70f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.PlayArrow, "Video preview", tint = Color.White, modifier = Modifier.size(18.dp))
                }
            }
        } else {
            Icon(fileIcon(entry), null, tint = accent, modifier = Modifier.size(26.dp))
        }
    }
}

private val ThumbnailCache = object : android.util.LruCache<String, Bitmap>(24 * 1024) {
    override fun sizeOf(key: String, value: Bitmap): Int = (value.byteCount / 1024).coerceAtLeast(1)
}

private fun createThumbnail(file: File): Bitmap? {
    val key = "${file.absolutePath}:${file.lastModified()}:${file.length()}"
    ThumbnailCache.get(key)?.let { return it }
    val bitmap = try {
        val mime = mimeType(file).orEmpty()
        when {
            isImageFile(file) || mime.startsWith("image/") -> {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeFile(file.absolutePath, bounds)
                var sample = 1
                while (bounds.outWidth / sample > 720 || bounds.outHeight / sample > 720) sample *= 2
                BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = Bitmap.Config.RGB_565
                })
            }
            isVideoFile(file) && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q -> ThumbnailUtils.createVideoThumbnail(file, Size(640, 640), null)
            isVideoFile(file) -> ThumbnailUtils.createVideoThumbnail(file.absolutePath, MediaStore.Images.Thumbnails.MINI_KIND)
            else -> null
        }
    } catch (_: Throwable) { null }
    if (bitmap != null) ThumbnailCache.put(key, bitmap)
    return bitmap
}

private fun isImageFile(file: File): Boolean = mimeType(file)?.startsWith("image/") == true ||
    file.extension.lowercase() in setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "heif", "bmp", "tif", "tiff", "avif")

private fun isVideoFile(file: File): Boolean = mimeType(file)?.startsWith("video/") == true ||
    file.extension.lowercase() in setOf("mp4", "mkv", "mov", "webm", "avi", "3gp", "m4v", "mpeg", "mpg", "ts", "wmv")

private fun fileIcon(entry: FileEntry) = when {
    entry.directory -> Icons.Default.Folder
    entry.mime?.startsWith("audio/") == true || entry.file.extension.lowercase() in setOf("mp3", "wav", "m4a", "aac", "ogg", "flac", "opus") -> Icons.Default.MusicNote
    isVideoFile(entry.file) -> Icons.Default.PlayCircle
    isImageFile(entry.file) -> Icons.Default.Image
    entry.mime?.contains("pdf") == true -> Icons.Default.PictureAsPdf
    entry.mime?.contains("zip") == true || entry.name.endsWith(".rar", true) || entry.name.endsWith(".7z", true) -> Icons.Default.FolderZip
    entry.mime?.contains("word") == true || entry.name.endsWith(".docx", true) -> Icons.Default.Description
    else -> Icons.Default.InsertDriveFile
}

private fun listDirectory(folder: File, showHidden: Boolean = false): List<FileEntry> = try {
    folder.listFiles()?.filter { it.canRead() && (showHidden || !it.name.startsWith(".")) }?.map { FileEntry(it) }?.sortedWith(compareBy<FileEntry> { !it.directory }.thenBy { it.name.lowercase() }) ?: emptyList()
} catch (_: Exception) { emptyList() }

private fun scanFiles(root: File, maxDepth: Int, maxDirectories: Int, showHidden: Boolean = false): List<FileEntry> {
    val results = mutableListOf<FileEntry>()
    val queue = ArrayDeque<Pair<File, Int>>()
    val visited = HashSet<String>()
    queue.add(root to 0)
    while (queue.isNotEmpty() && visited.size < maxDirectories) {
        val (folder, depth) = queue.removeFirst()
        val key = try { folder.canonicalPath } catch (_: Exception) { folder.absolutePath }
        if (!visited.add(key)) continue
        val children = try { folder.listFiles() } catch (_: Exception) { null } ?: continue
        for (child in children) {
            val path = child.absolutePath.replace('\\', '/')
            if ((!showHidden && child.name.startsWith(".")) || path.contains("/Android/data/") || path.endsWith("/Android/data") || path.contains("/Android/obb/") || path.endsWith("/Android/obb")) continue
            if (child.isFile) results.add(FileEntry(child))
            else if (child.isDirectory && depth < maxDepth && child.canRead()) queue.add(child to depth + 1)
        }
    }
    return results
}

private fun inCategory(file: File, category: String): Boolean {
    val lower = file.name.lowercase()
    val mime = mimeType(file).orEmpty()
    return when (category) {
        "Images" -> mime.startsWith("image/") || listOf(".jpg", ".jpeg", ".png", ".gif", ".webp", ".heic", ".bmp", ".svg").any { lower.endsWith(it) }
        "Videos" -> mime.startsWith("video/") || listOf(".mp4", ".mkv", ".mov", ".webm", ".avi", ".3gp", ".m4v").any { lower.endsWith(it) }
        "Audio" -> mime.startsWith("audio/") || listOf(".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac", ".opus").any { lower.endsWith(it) }
        "Documents" -> mime.startsWith("text/") || listOf(".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".csv", ".rtf", ".odt").any { lower.endsWith(it) }
        "Downloads" -> file.absolutePath.contains("/Download/", ignoreCase = true) || file.parentFile?.name.equals("Download", ignoreCase = true)
        "Large files" -> file.length() >= 100L * 1024L * 1024L
        else -> true
    }
}

private fun mimeType(file: File): String? = try {
    val extension = file.extension.lowercase()
    if (extension.isBlank()) null else android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension)
} catch (_: Exception) { null }

private fun openFile(context: Context, file: File) {
    try {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        context.startActivity(Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType(file) ?: "*/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        })
    } catch (_: Exception) {
        Toast.makeText(context, "No compatible app found to open this file", Toast.LENGTH_SHORT).show()
    }
}

private fun shareFile(context: Context, file: File) {
    try {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = mimeType(file) ?: "*/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "Share file"))
    } catch (_: Exception) {
        Toast.makeText(context, "Could not share this item", Toast.LENGTH_SHORT).show()
    }
}

private fun storageStats(): Pair<Long, Long> = try {
    val stat = StatFs(RootStorage.absolutePath)
    val total = stat.totalBytes
    val free = stat.availableBytes
    (total - free).coerceAtLeast(0L) to total.coerceAtLeast(0L)
} catch (_: Exception) { 0L to 0L }

private fun humanSize(size: Long): String {
    if (size < 0L) return "Unknown size"
    if (size == 0L) return "0 B"
    val units = listOf("B", "KB", "MB", "GB", "TB")
    var value = size.toDouble(); var index = 0
    while (value >= 1024 && index < units.lastIndex) { value /= 1024; index++ }
    return String.format("%.1f %s", value, units[index])
}
