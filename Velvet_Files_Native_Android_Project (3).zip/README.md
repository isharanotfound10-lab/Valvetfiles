# File Manager — Liquid Glass Edition

A native Android file manager built with Kotlin and Jetpack Compose. The launcher label is **File Manager**.

## Included

- AMOLED-first liquid-glass interface with layered translucent gradients, rounded panels, soft borders, and themed accents.
- Six selectable, saved themes: Liquid Glass, Arctic Aurora, Rose Quartz, Emerald Hologram, Sunset Prism, and Pure AMOLED.
- A dedicated Settings screen for themes, grid/list preference, compact rows, and hidden files.
- Google Files-inspired home categories for Images, Videos, Audio, Documents, Downloads, and Large files.
- Internal shared-storage browsing, search, sorting by name/date/size, and grid/list views.
- Photo thumbnails and video-frame previews in file rows, recent items, and larger image/video grid cards.
- Create folder, open, share, rename, delete, copy, and move operations.
- Storage usage meter and a recent-modified-files section.
- Preferences saved across app restarts.

## Build

The project is designed to build in GitHub Actions with Java 17, Android SDK 35, and Gradle. From the extracted project root run:

```bash
gradle assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Storage access notes

On Android 11 and later, the app requests Android's special **All files access** permission to manage shared storage. Users must approve this on the system Settings screen. Android still restricts some app-private or protected locations; this permission is not root access.

## Validation status

The source and ZIP structure have been checked in this environment, but a complete Android Gradle build of this revision has not yet been run here. Use the GitHub Actions build result as the compile check before installing the APK.
